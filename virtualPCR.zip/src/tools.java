import java.util.ArrayList;
import java.util.Arrays;

public final class tools {

    public static final int minoligolen = 12;
    public static final int maxoligolen = 500;

    public static String RandomDNA(int i) {
        String[] x2 = {"ca", "ta", "ga", "aa", "ct", "tt", "gt", "at", "cc", "tc", "gc", "ac", "cg", "tg", "gg", "ag"};
        String[] x3 = {"aca", "ata", "aga", "aaa", "act", "att", "agt", "aat", "acc", "atc", "agc", "aac", "acg", "atg", "agg", "aag",
            "gca", "gta", "gga", "gaa", "gct", "gtt", "ggt", "gat", "gcc", "gtc", "ggc", "gac", "gcg", "gtg", "ggg", "gag",
            "cca", "cta", "cga", "caa", "cct", "ctt", "cgt", "cat", "ccc", "ctc", "cgc", "cac", "ccg", "ctg", "cgg", "cag",
            "tca", "tta", "tga", "taa", "tct", "ttt", "tgt", "tat", "tcc", "ttc", "tgc", "tac", "tcg", "ttg", "tgg", "tag"};
        if (i < 1000) {
            i = 1000;
        }
        if (i > 10000) {
            i = 10000;
        }
        int n = i / 5;
        StringBuilder x = new StringBuilder(i);
        for (int h = 0; h < n; h++) {
            x.append(x2[(int) (Math.random() * 16)]).append(x3[(int) (Math.random() * 64)]);
        }
        return x.toString();
    }

    public static double[] PlotRYskew(String source, int k) {
        int[] h = new int[128];
        h[97] = 1;
        h[98] = 3; //0.33d;
        h[99] = 2;
        h[100] = 5; //0.66d;
        h[103] = 1;
        h[104] = 3; //0.33d;
        h[105] = 1;
        h[107] = 4; // 0.5d;
        h[109] = 4; // 0.5d;
        h[110] = 4; // 0.5d;
        h[114] = 1;
        h[115] = 4; // 0.5d;
        h[116] = 2;
        h[118] = 5; //0.66d;
        h[119] = 4; // 0.5d;
        h[121] = 2;

        int l = source.length();
        if (k < minoligolen) {
            k = minoligolen;
        }
        if (l < k || l < minoligolen) {
            return null;
        }
        if (l < k) {
            k = l;
        }

        int n = 0;
        double r = 0d;
        double y = 0d;
        double[] x = new double[1 + l - k];
        double[] y1 = {0, 0, 1, 0.333d, 0.5d, 0666d};
        double[] r1 = {0, 1, 0, 0.333d, 0.5d, 0666d};

        for (int i = 0; i < k; i++) {
            n = h[source.charAt(i)];
            if (n == 0) {
                continue;
            }
            y = y + y1[n];
            r = r + r1[n];
        }
        x[0] = (r - y) / k;

        for (int i = 1; i < l - k + 1; i++) {
            n = h[source.charAt(i - 1)];
            if (n == 0) {
                continue;
            }
            y = y - y1[n];
            r = r - r1[n];
            n = h[source.charAt(i + k - 1)];
            y = y + y1[n];
            r = r + r1[n];
            x[i] = (r - y) / k;
        }
        return x;
    }
// need to do

    public static String[] SequenceSplitter(String source, String m) {
        // source = "nancgacgcgcnnnacgacgacgnc";
        String[] s = source.split(m);
        ArrayList<String> h = new ArrayList();

        int n = s.length;
        String x = "";
        for (int i = 0; i < n; i++) {
            int l = s[i].length();
            if (l == 0) {
                x = x + "n";
            } else {
                h.add((x + s[i] + "n"));
                x = "";
            }

        }

        if (n < 2) {
            return s;
        }
        return s;
    }

    public static String[] SequenceIncreaser(String source, String m) {
        // source = "DQ788719-DQ788722";
        String[] s = source.split(m);
        if (s.length == 1 | s.length > 2) {
            return s;
        }

        for (int i = 0; i < s[0].length(); i++) {
            if (Character.isDigit(s[0].charAt(i))) {
                String z1 = "";
                //      String z2 = "";
                if (i > 0) {
                    z1 = s[0].substring(0, i);
                    //         z2 = s[1].substring(0, i);
                }

                int n1 = SeqToInt(s[0].substring(i));
                int n2 = SeqToInt(s[1].substring(i));
                if (n2 > n1) {
                    ArrayList<String> h = new ArrayList();
                    h.add(s[0]);
                    for (int j = n1 + 1; j < n2; j++) {
                        h.add(z1 + j);
                    }
                    h.add(s[1]);
                    return h.stream().toArray(String[]::new);
                }
            }
        }
        return s;
    }

    public static double[] PlotMKskew(String source, int k) {
        int[] h = new int[128];
        h[97] = 1;
        h[98] = 3;  //0.33d;
        h[99] = 1;
        h[100] = 3; //0.66d;
        h[103] = 2;
        h[104] = 5; //0.33d;
        h[105] = 2;
        h[107] = 2; //0.5d;
        h[109] = 1; //0.5d;
        h[110] = 4; //0.5d;
        h[114] = 4;
        h[115] = 4; //0.5d;
        h[116] = 2;
        h[118] = 5; //0.66d;
        h[119] = 4; //0.5d;
        h[121] = 4;

        int l = source.length();
        if (k < minoligolen) {
            k = minoligolen;
        }
        if (l < k || l < minoligolen) {
            return null;
        }
        if (l < k) {
            k = l;
        }

        int i = 0;
        int n = 0;
        double m = 0d;
        double y = 0d;
        double[] x = new double[1 + l - k];
        double[] y1 = {0, 0, 1, 0.333d, 0.5d, 0666d};
        double[] m1 = {0, 1, 0, 0.333d, 0.5d, 0666d};

        for (i = 0; i < k; i++) {
            n = h[source.charAt(i)];
            if (n == 0) {
                continue;
            }
            y = y + y1[n];
            m = m + m1[n];
        }
        x[0] = (m - y) / k;

        for (i = 1; i < l - k + 1; i++) {
            n = h[source.charAt(i - 1)];
            if (n == 0) {
                continue;
            }
            y = y - y1[n];
            m = m - m1[n];
            n = h[source.charAt(i + k - 1)];
            y = y + y1[n];
            m = m + m1[n];
            x[i] = (m - y) / k;
        }
        return x;
    }

    public static double[] PlotSWskew(String source, int k) {
        double[] h = new double[128];
        int[] v = new int[128];
        v[97] = 2;
        h[97] = 1d;
        v[98] = 3;
        h[98] = 0.666d;
        v[99] = 1;
        h[99] = 1d;
        v[100] = 3;
        h[100] = 0.333d;
        v[103] = 1;
        h[103] = 1d;
        v[104] = 3;
        h[104] = 0.333d;
        v[105] = 1;
        h[105] = 1d;
        v[107] = 3;
        h[107] = 0.5d;
        v[109] = 3;
        h[109] = 0.5d;
        v[110] = 3;
        h[110] = 0.5d;
        v[114] = 3;
        h[114] = 0.5d;
        v[115] = 1;
        h[115] = 1d;
        v[116] = 2;
        h[116] = 1d;
        v[118] = 3;
        h[118] = 0.666d;
        v[119] = 2;
        h[119] = 1d;
        v[121] = 3;
        h[121] = 0.5d;
//CG-AT skew: (G+C-A-T)/n
//cg = 1 at = 2
        int l = source.length();
        if (k < minoligolen) {
            k = minoligolen;
        }
        if (l < k || l < minoligolen) {
            return null;
        }
        if (l < k) {
            k = l;
        }

        int i = 0;
        int z = 0;
        int n = 0;
        double cg = 0d;
        double at = 0d;
        double[] r = new double[1 + l - k];

        for (i = 0; i < k; i++) {
            z = source.charAt(i);
            n = v[z];
            if (n == 0) {
                continue;
            }
            if (n == 1) {
                cg = cg + h[z];
            }
            if (n == 2) {
                at = at + h[z];
            }
            if (n == 3) {
                cg = cg + h[z];
                at = at + 1 - h[z];
            }
        }
        r[0] = (cg - at) / k;

        for (i = 1; i < l - k + 1; i++) {
            z = source.charAt(i - 1);
            n = v[z];
            if (n > 0) {
                if (n == 1) {
                    cg = cg - h[z];
                }
                if (n == 2) {
                    at = at - h[z];
                }
                if (n == 3) {
                    cg = cg - h[z];
                    at = at - 1 + h[z];
                }
            }
            z = source.charAt(i + k - 1);
            n = v[z];
            if (n > 0) {
                if (n == 1) {
                    cg = cg + h[z];
                }
                if (n == 2) {
                    at = at + h[z];
                }
                if (n == 3) {
                    cg = cg + h[z];
                    at = at + 1 - h[z];
                }
            }
            r[i] = (cg - at) / k;
        }
        return r;
    }

    public static double[] PlotATskew(String source, int k) {
        double[] h = new double[128];
        int[] v = new int[128];
        v[97] = 1;
        h[97] = 1d;
        v[98] = 2;
        h[98] = 0.333d;
        v[100] = 3;
        h[100] = 0.333d;
        v[104] = 3;
        h[104] = 0.333d;
        v[107] = 2;
        h[107] = 0.5d;
        v[109] = 1;
        h[109] = 0.5d;
        v[110] = 3;
        h[110] = 0.25d;
        v[114] = 1;
        h[114] = 0.5d;
        v[116] = 2;
        h[116] = 1d;
        v[118] = 1;
        h[118] = 0.333d;
        v[119] = 3;
        h[119] = 0.5d;
        v[121] = 2;
        h[121] = 0.5d;
//a=1 t=2
        int l = source.length();
        if (k < minoligolen) {
            k = minoligolen;
        }
        if (l < k || l < minoligolen) {
            return null;
        }
        if (l < k) {
            k = l;
        }

        int i = 0;
        int n = 0;
        double a = 0d;
        double t = 0d;
        double[] r = new double[1 + l - k];
        byte[] b = source.getBytes();

        for (i = 0; i < k; i++) {
            n = v[b[i]];
            if (n > 0) {
                if (n == 1) {
                    a = a + h[b[i]];
                }
                if (n == 2) {
                    t = t + h[b[i]];
                }
                if (n == 3) {
                    a = a + h[b[i]];
                    t = t + h[b[i]];
                }
            }
        }
        r[0] = (a + t > 0) ? (a - t) / (a + t) : 0;

        for (i = 1; i < l - k + 1; i++) {
            n = v[b[i - 1]];
            if (n > 0) {
                if (n == 1) {
                    a = a - h[b[i - 1]];
                }
                if (n == 2) {
                    t = t - h[b[i - 1]];
                }
                if (n == 3) {
                    a = a - h[b[i - 1]];
                    t = t - h[b[i - 1]];
                }
            }
            n = v[b[i + k - 1]];
            if (n > 0) {
                if (n == 1) {
                    a = a + h[b[i + k - 1]];
                }
                if (n == 2) {
                    t = t + h[b[i + k - 1]];
                }
                if (n == 3) {
                    a = a + h[b[i + k - 1]];
                    t = t + h[b[i + k - 1]];
                }
            }
            r[i] = (a + t > 0) ? (a - t) / (a + t) : 0;
        }
        return r;
    }

    public static double[] PlotCGskew(String source, int k) {
        double[] h = new double[128];
        int[] v = new int[128];
        v[98] = 3;
        h[98] = 0.333d;
        v[99] = 2;
        h[99] = 1d;
        v[100] = 1;
        h[100] = 0.333d;
        v[103] = 1;
        h[103] = 1d;
        v[104] = 2;
        h[104] = 0.333d;
        v[105] = 1;
        h[105] = 1d;
        v[107] = 1;
        h[107] = 0.5d;
        v[109] = 2;
        h[109] = 0.5d;
        v[110] = 3;
        h[110] = 0.5d;
        v[114] = 1;
        h[114] = 0.5d;
        v[115] = 3;
        h[115] = 0.5d;
        v[118] = 3;
        h[118] = 0.333d;
        v[121] = 2;
        h[121] = 0.5d;
//g =1 c=2
        int l = source.length();
        if (k < minoligolen) {
            k = minoligolen;
        }
        if (l < k || l < minoligolen) {
            return null;
        }
        if (l < k) {
            k = l;
        }
        int i = 0;
        int n = 0;
        double c = 0d;
        double g = 0d;
        double[] r = new double[1 + l - k];
        byte[] b = source.getBytes();

        for (i = 0; i < k; i++) {
            n = v[b[i]];
            if (n > 0) {
                if (n == 1) {
                    g = g + h[b[i]];
                }
                if (n == 2) {
                    c = c + h[b[i]];
                }
                if (n == 3) {
                    g = g + h[b[i]];
                    c = c + h[b[i]];
                }
            }
        }
        r[0] = (c + g > 0) ? (g - c) / (g + c) : 0;

        for (i = 1; i < l - k + 1; i++) {
            n = v[b[i - 1]];
            if (n > 0) {
                if (n == 1) {
                    g = g - h[b[i - 1]];
                }
                if (n == 2) {
                    c = c - h[b[i - 1]];
                }
                if (n == 3) {
                    c = c - h[b[i - 1]];
                    g = g - h[b[i - 1]];
                }
            }
            n = v[b[i + k - 1]];
            if (n > 0) {
                if (n == 1) {
                    g = g + h[b[i + k - 1]];
                }
                if (n == 2) {
                    c = c + h[b[i + k - 1]];
                }
                if (n == 3) {
                    c = c + h[b[i + k - 1]];
                    g = g + h[b[i + k - 1]];
                }
            }
            r[i] = (c + g > 0) ? (g - c) / (g + c) : 0;
        }
        return r;
    }

    public static int[] PlotQ(String source, int k) {
        int l = source.length();
        if (k < minoligolen) {
            k = minoligolen;
        }
        if (l < k || l < minoligolen) {
            return null;
        }
        if (l < k) {
            k = l;
        }
        int[] r = new int[1 + l - k];
        for (int i = 0; i < l - k + 1; i++) {
            String a = source.substring(i, k + i);
            r[i] = Oligo.PrimerQuality(a, 1);
        }
        return r;
    }

    public static double[] PlotCG(String source, int k) {
        double[] cdn = new double[128];
        cdn[98] = 0.666d;   //b
        cdn[99] = 1d;       //c
        cdn[100] = 0.333d;  //d
        cdn[103] = 1d;      //g
        cdn[104] = 0.333d;  //h   
        cdn[105] = 1d;      //i        
        cdn[107] = 0.5d;    //k
        cdn[109] = 0.5d;    //m
        cdn[110] = 0.5d;    //n
        cdn[114] = 0.5d;    //r
        cdn[115] = 1d;      //s
        cdn[118] = 0.666d;  //v
        cdn[121] = 0.5d;    //y
        double cg = 0d;
        int l = source.length();
        if (k < minoligolen) {
            k = minoligolen;
        }
        if (l < k || l < minoligolen) {
            return null;
        }
        if (l < k) {
            k = l;
        }
        double[] r = new double[1 + l - k];
        for (int i = 0; i < k; i++) {
            cg = cg + cdn[source.charAt(i)];
        }
        r[0] = (100 * cg) / k;

        for (int i = 1; i < l - k + 1; i++) {
            cg = cg - cdn[source.charAt(i - 1)] + cdn[source.charAt(i + k - 1)];
            r[i] = (100 * cg) / k;
        }
        return r;
    }

    public static double[] PlotGA(String source, int k) {
        double[] cdn = new double[128];
        cdn[97] = 1d;       //A
        cdn[98] = 0.33d;    //B=(C/G/T]
        cdn[99] = 0;        //C
        cdn[100] = 0.67d;   //D=(A/G/T]
        cdn[101] = 1d;      //A
        cdn[102] = 0;       //dC LNA
        cdn[103] = 1d;      //G
        cdn[104] = 0.33d;   //H=(A/C/T]
        cdn[105] = 1d;      //i=G
        cdn[106] = 1d;      //dG LNA
        cdn[107] = 0.5d;    //K=(G/T]
        cdn[109] = 0.50d;   //M=(A/C]
        cdn[110] = 0.50d;   //N=(A/G/C/T]
        cdn[114] = 1d;      //R=(A/G]
        cdn[115] = 0.50d;   //S=(G/C]
        cdn[118] = 0.67d;   //V=(A/G/C]
        cdn[119] = 0.50d;   //W=(A/T]
        cdn[121] = 0;       //Y=(C/T]

        double ga = 0d;
        int l = source.length();
        if (k < minoligolen) {
            k = minoligolen;
        }
        if (l < k || l < minoligolen) {
            return null;
        }
        if (l < k) {
            k = l;
        }
        double[] r = new double[1 + l - k];
        for (int i = 0; i < k; i++) {
            ga = ga + cdn[source.charAt(i)];
        }
        r[0] = (100 * ga) / k;

        for (int i = 1; i < l - k + 1; i++) {
            ga = ga - cdn[source.charAt(i - 1)] + cdn[source.charAt(i + k - 1)];
            r[i] = (100 * ga) / k;
        }
        return r;
    }

    public static String UcaseDNA(String source, int x1, int x2) {
        char[] b = source.toCharArray();
        int l = b.length;

        if (x1 > l) {
            x1 = l;
        }
        if (x2 < x1 || x2 > l) {
            x2 = 0;
        }
        if (x1 <= 0) {
            x1 = l - x2;
            x2 = l;
        }

        for (int i = x1; i < x2; i++) {
            b[i] = (char) (b[i] - 32);
        }
        return new String(b);
    }

    public static int DNAtest(String source) {
        byte[] cdn = new byte[128];
        cdn[65] = 1;   //A
        cdn[66] = 1;   //B
        cdn[67] = 1;   //C
        cdn[68] = 1;   //D
        cdn[71] = 1;   //G
        cdn[72] = 1;   //H
        cdn[75] = 1;   //K
        cdn[77] = 1;   //M
        cdn[78] = 1;   //N
        cdn[82] = 1;   //R
        cdn[83] = 1;   //S
        cdn[84] = 1;   //T
        cdn[85] = 1;   //U
        cdn[86] = 1;   //V
        cdn[87] = 1;   //W
        cdn[89] = 1;   //Y
        cdn[97] = 1;   //a
        cdn[98] = 1;   //b
        cdn[99] = 1;   //c
        cdn[100] = 1;  //d
        cdn[103] = 1;  //g
        cdn[104] = 1;  //h
        cdn[107] = 1;  //k
        cdn[109] = 1;  //m
        cdn[110] = 1;  //n
        cdn[114] = 1;  //r
        cdn[115] = 1;  //s
        cdn[116] = 1;  //t
        cdn[117] = 1;  //u
        cdn[118] = 1;  //v
        cdn[119] = 1;  //w
        cdn[121] = 1;  //y
        for (int i = 0; i < source.length(); i++) {
            int k = source.charAt(i);
            if (k > 64 && k < 122 && cdn[k] > 0) {
                return 1;
            }
        }
        return 0;
    }

    public static String NumberToSeq(double d, int i) {
        String s = "0.0";
        if (i == 0) {
            s = "##";
        }
        if (i > 1) {
            char[] value1 = new char[i];
            for (int j = 0; j < i; j++) {
                value1[j] = '0';
            }
            s = "0." + new String(value1);
        }
        java.text.DecimalFormat f1 = new java.text.DecimalFormat(s);
        return (f1.format(d));
    }

    public static double SeqToDouble(String str) {
        StringBuilder r = new StringBuilder();
        int n = 0;
        int z = 0;
        r.append(0);
        for (int i = 0; i < str.length(); i++) {
            char chr = str.charAt(i);
            if (chr > 47 && chr < 58) {
                r.append(chr);
                z++;
                if (z > 10) {
                    break;
                }
            }
            if (chr == '.' || chr == ',') {
                if (n == 0) {
                    r.append('.');
                    n = 1;
                }
            }
        }
        // return (Double.valueOf("0" + r.toString()).doubleValue());
        return (Double.parseDouble(r.toString()));
    }

    public static int SeqToInt(String str) {
        StringBuilder r = new StringBuilder();
        int z = 0;
        r.append(0);
        for (int i = 0; i < str.length(); i++) {
            char chr = str.charAt(i);
            if (chr > 47 && chr < 58) {
                r.append(chr);
                z++;
                if (z > 10) {
                    break;
                }
            }
            if (chr == '.' || chr == ',') {
                break;
            }
        }
        return (Integer.parseInt(r.toString()));
    }

    public static String Strings(int n, char c) {
        if (n < 1) {
            n = 1;
        }
        char[] value1 = new char[n];
        for (int i = 0; i < n; i++) {
            value1[i] = c;
        }
        return new String(value1);
    }

    public static int FindSSR(String seq, ArrayList<SSRInfo> RArray) {
        int n1;
        int n2;
        int n3;
        int x;
        int e;
        int z = 0;
        int j;

        int l = seq.length();
        if (l < 21) {
            return 0;
        }

        byte[][] v2 = new byte[5][5];
        byte[][][] v3 = new byte[5][5][5];
        byte[] k2 = new byte[l - 16];

        byte b[] = seq.getBytes();
        for (int i = 0; i < l; i++) {
            b[i] = tables.dx2[b[i]];
        }

        for (int i = 0; i < 17; i++) {
            n1 = b[i];    //16
            n2 = b[i + 1];//17
            v2[n1][n2]++;
            if (v2[n1][n2] == 1) {
                k2[0]++;
            }
        }

        for (int i = 0; i < 16; i++) {
            n1 = b[i];     //15
            n2 = b[i + 1]; //16
            n3 = b[i + 2]; //17
            v3[n1][n2][n3]++;
            if (v3[n1][n2][n3] == 1) {
                k2[0]++;
            }
        }

        for (int i = 1; i < l - 17; i++) {
            k2[i] = k2[i - 1];
            n1 = b[i - 1];
            n2 = b[i];
            n3 = b[i + 1];
            v2[n1][n2]--;
            if (v2[n1][n2] == 0) {
                k2[i]--;
            }

            v3[n1][n2][n3]--;
            if (v3[n1][n2][n3] == 0) {
                k2[i]--;
            }

            n1 = b[i + 15]; //16
            n2 = b[i + 16]; //17
            n3 = b[i + 17]; //18
            v2[n2][n3]++;
            if (v2[n2][n3] == 1) {
                k2[i]++;
            }

            v3[n1][n2][n3]++;
            if (v3[n1][n2][n3] == 1) {
                k2[i]++;
            }
        }

        for (int i = 0; i < l - 17; i++) {
            if (k2[i] < 12) {
                x = i;
                for (e = i + 1; e < l - 17; e++) {
                    if (k2[e] > 12) {
                        break;
                    }
                }
                i = e - 1;
                if (e - x > 12) {
                    if (x > 0) {
                        x--;
                    }
                    z++;
                    SSRInfo t1 = new SSRInfo();
                    t1.x = x;
                    t1.e = e + 16;
                    t1.tag = seq.substring(x, e);
                    RArray.add(t1);
                }
            }
        }
        return z;
    }

    public static int[] PlotLC(String source, int n) {
        int l = source.length();
        int i = 0;
        int k = 2;
        int n1 = 0;
        int n2 = 0;
        int n3 = 0;
        int n4 = 0;
        int n5 = 0;
        int n6 = 0;
        int n7 = 0;

        if (l < minoligolen) {
            return null;
        }
        if (n < minoligolen) {
            n = minoligolen;
        }
        if (l < n) {
            n = l;
        }

        byte b[] = source.getBytes();
        for (i = 0; i < l; i++) {
            b[i] = tables.dx2[b[i]];
        }

        int[] y1 = new int[5];
        int[][] y2 = new int[5][5];
        int[][][] y3 = new int[5][5][5];
        int[] X = new int[1 + l - n];

        int t = 4 + (n > 16 ? 16 : n - 1);
        if (n > 12) {
            t = t + (n > 65 ? 64 : n - 2);
            k = 3;
        }
        if (n > 48) {
            t = t + (n > 258 ? 256 : n - 3);
            k = 4;
        }
        if (n > 192) {
            t = t + (n > 1027 ? 1024 : n - 4);
            k = 5;
        }
        if (n > 768) {
            t = t + (n > 5000 ? 4096 : n - 5);
            k = 6;
        }
        if (n > 3072) {
            t = t + (n > 16389 ? 16384 : n - 6);
            k = 7;
        }

        if (k == 7) {
            int[][][][] y4 = new int[5][5][5][5];
            int[][][][][] y5 = new int[5][5][5][5][5];
            int[][][][][][] y6 = new int[5][5][5][5][5][5];
            int[][][][][][][] y7 = new int[5][5][5][5][5][5][5];
            for (i = 0; i < n - 6; i++) {
                n1 = b[i];
                n2 = b[i + 1];
                n3 = b[i + 2];
                n4 = b[i + 3];
                n5 = b[i + 4];
                n6 = b[i + 5];
                n7 = b[i + 6];
                y1[n1]++;
                if (y1[n1] == 1) {
                    X[0]++;
                }
                y2[n1][n2]++;
                if (y2[n1][n2] == 1) {
                    X[0]++;
                }
                y3[n1][n2][n3]++;
                if (y3[n1][n2][n3] == 1) {
                    X[0]++;
                }
                y4[n1][n2][n3][n4]++;
                if (y4[n1][n2][n3][n4] == 1) {
                    X[0]++;
                }
                y5[n1][n2][n3][n4][n5]++;
                if (y5[n1][n2][n3][n4][n5] == 1) {
                    X[0]++;
                }
                y6[n1][n2][n3][n4][n5][n6]++;
                if (y6[n1][n2][n3][n4][n5][n6] == 1) {
                    X[0]++;
                }
                y7[n1][n2][n3][n4][n5][n6][n7]++;
                if (y7[n1][n2][n3][n4][n5][n6][n7] == 1) {
                    X[0]++;
                }
            }
            y6[n2][n3][n4][n5][n6][n7]++;
            if (y6[n2][n3][n4][n5][n6][n7] == 1) {
                X[0]++;
            }
            y5[n2][n3][n4][n5][n6]++;
            if (y5[n2][n3][n4][n5][n6] == 1) {
                X[0]++;
            }
            y5[n3][n4][n5][n6][n7]++;
            if (y5[n3][n4][n5][n6][n7] == 1) {
                X[0]++;
            }
            y4[n2][n3][n4][n5]++;
            if (y4[n2][n3][n4][n5] == 1) {
                X[0]++;
            }
            y4[n3][n4][n5][n6]++;
            if (y4[n3][n4][n5][n6] == 1) {
                X[0]++;
            }
            y4[n4][n5][n6][n7]++;
            if (y4[n4][n5][n6][n7] == 1) {
                X[0]++;
            }
            y3[n5][n6][n7]++;
            if (y3[n5][n6][n7] == 1) {
                X[0]++;
            }
            y3[n4][n5][n6]++;
            if (y3[n4][n5][n6] == 1) {
                X[0]++;
            }
            y3[n3][n4][n5]++;
            if (y3[n3][n4][n5] == 1) {
                X[0]++;
            }
            y3[n2][n3][n4]++;
            if (y3[n2][n3][n4] == 1) {
                X[0]++;
            }
            y2[n6][n7]++;
            if (y2[n6][n7] == 1) {
                X[0]++;
            }
            y2[n5][n6]++;
            if (y2[n5][n6] == 1) {
                X[0]++;
            }
            y2[n4][n5]++;
            if (y2[n4][n5] == 1) {
                X[0]++;
            }
            y2[n3][n4]++;
            if (y2[n3][n4] == 1) {
                X[0]++;
            }
            y2[n2][n3]++;
            if (y2[n2][n3] == 1) {
                X[0]++;
            }
            y1[n2]++;
            if (y1[n2] == 1) {
                X[0]++;
            }
            y1[n3]++;
            if (y1[n3] == 1) {
                X[0]++;
            }
            y1[n4]++;
            if (y1[n4] == 1) {
                X[0]++;
            }
            y1[n5]++;
            if (y1[n5] == 1) {
                X[0]++;
            }
            y1[n6]++;
            if (y1[n6] == 1) {
                X[0]++;
            }
            y1[n7]++;
            if (y1[n7] == 1) {
                X[0]++;
            }
            for (i = 1; i < l - n + 1; i++) {
                X[i] = X[i - 1];
                n1 = b[i - 1];
                n2 = b[i];
                n3 = b[i + 1];
                n4 = b[i + 2];
                n5 = b[i + 3];
                n6 = b[i + 4];
                n7 = b[i + 5];
                y1[n1]--;
                if (y1[n1] == 0) {
                    X[i]--;
                }
                y2[n1][n2]--;
                if (y2[n1][n2] == 0) {
                    X[i]--;
                }
                y3[n1][n2][n3]--;
                if (y3[n1][n2][n3] == 0) {
                    X[i]--;
                }
                y4[n1][n2][n3][n4]--;
                if (y4[n1][n2][n3][n4] == 0) {
                    X[i]--;
                }
                y5[n1][n2][n3][n4][n5]--;
                if (y5[n1][n2][n3][n4][n5] == 0) {
                    X[i]--;
                }
                y6[n1][n2][n3][n4][n5][n6]--;
                if (y6[n1][n2][n3][n4][n5][n6] == 0) {
                    X[i]--;
                }
                y7[n1][n2][n3][n4][n5][n6][n7]--;
                if (y7[n1][n2][n3][n4][n5][n6][n7] == 0) {
                    X[i]--;
                }
                n1 = b[i + n - 1];
                n2 = b[i + n - 2];
                n3 = b[i + n - 3];
                n4 = b[i + n - 4];
                n5 = b[i + n - 5];
                n6 = b[i + n - 6];
                n7 = b[i + n - 7];
                y1[n1]++;
                if (y1[n1] == 1) {
                    X[i]++;
                }
                y2[n2][n1]++;
                if (y2[n2][n1] == 1) {
                    X[i]++;
                }
                y3[n3][n2][n1]++;
                if (y3[n3][n2][n1] == 1) {
                    X[i]++;
                }
                y4[n4][n3][n2][n1]++;
                if (y4[n4][n3][n2][n1] == 1) {
                    X[i]++;
                }
                y5[n5][n4][n3][n2][n1]++;
                if (y5[n5][n4][n3][n2][n1] == 1) {
                    X[i]++;
                }
                y6[n6][n5][n4][n3][n2][n1]++;
                if (y6[n6][n5][n4][n3][n2][n1] == 1) {
                    X[i]++;
                }
                y7[n7][n6][n5][n4][n3][n2][n1]++;
                if (y7[n7][n6][n5][n4][n3][n2][n1] == 1) {
                    X[i]++;
                }
                X[i - 1] = (X[i - 1] * 100) / t;
            }
        }

        if (k == 6) {
            int[][][][] y4 = new int[5][5][5][5];
            int[][][][][] y5 = new int[5][5][5][5][5];
            int[][][][][][] y6 = new int[5][5][5][5][5][5];
            for (i = 0; i < n - 5; i++) {
                n1 = b[i];
                n2 = b[i + 1];
                n3 = b[i + 2];
                n4 = b[i + 3];
                n5 = b[i + 4];
                n6 = b[i + 5];
                y1[n1]++;
                if (y1[n1] == 1) {
                    X[0]++;
                }
                y2[n1][n2]++;
                if (y2[n1][n2] == 1) {
                    X[0]++;
                }
                y3[n1][n2][n3]++;
                if (y3[n1][n2][n3] == 1) {
                    X[0]++;
                }
                y4[n1][n2][n3][n4]++;
                if (y4[n1][n2][n3][n4] == 1) {
                    X[0]++;
                }
                y5[n1][n2][n3][n4][n5]++;
                if (y5[n1][n2][n3][n4][n5] == 1) {
                    X[0]++;
                }
                y6[n1][n2][n3][n4][n5][n6]++;
                if (y6[n1][n2][n3][n4][n5][n6] == 1) {
                    X[0]++;
                }
            }
            y5[n2][n3][n4][n5][n6]++;
            if (y5[n2][n3][n4][n5][n6] == 1) {
                X[0]++;
            }
            y4[n2][n3][n4][n5]++;
            if (y4[n2][n3][n4][n5] == 1) {
                X[0]++;
            }
            y4[n3][n4][n5][n6]++;
            if (y4[n3][n4][n5][n6] == 1) {
                X[0]++;
            }
            y3[n4][n5][n6]++;
            if (y3[n4][n5][n6] == 1) {
                X[0]++;
            }
            y3[n3][n4][n5]++;
            if (y3[n3][n4][n5] == 1) {
                X[0]++;
            }
            y3[n2][n3][n4]++;
            if (y3[n2][n3][n4] == 1) {
                X[0]++;
            }
            y2[n5][n6]++;
            if (y2[n5][n6] == 1) {
                X[0]++;
            }
            y2[n4][n5]++;
            if (y2[n4][n5] == 1) {
                X[0]++;
            }
            y2[n3][n4]++;
            if (y2[n3][n4] == 1) {
                X[0]++;
            }
            y2[n2][n3]++;
            if (y2[n2][n3] == 1) {
                X[0]++;
            }
            y1[n2]++;
            if (y1[n2] == 1) {
                X[0]++;
            }
            y1[n3]++;
            if (y1[n3] == 1) {
                X[0]++;
            }
            y1[n4]++;
            if (y1[n4] == 1) {
                X[0]++;
            }
            y1[n5]++;
            if (y1[n5] == 1) {
                X[0]++;
            }
            y1[n6]++;
            if (y1[n6] == 1) {
                X[0]++;
            }
            for (i = 1; i < l - n + 1; i++) {
                X[i] = X[i - 1];
                n1 = b[i - 1];
                n2 = b[i];
                n3 = b[i + 1];
                n4 = b[i + 2];
                n5 = b[i + 3];
                n6 = b[i + 4];
                y1[n1]--;
                if (y1[n1] == 0) {
                    X[i]--;
                }
                y2[n1][n2]--;
                if (y2[n1][n2] == 0) {
                    X[i]--;
                }
                y3[n1][n2][n3]--;
                if (y3[n1][n2][n3] == 0) {
                    X[i]--;
                }
                y4[n1][n2][n3][n4]--;
                if (y4[n1][n2][n3][n4] == 0) {
                    X[i]--;
                }
                y5[n1][n2][n3][n4][n5]--;
                if (y5[n1][n2][n3][n4][n5] == 0) {
                    X[i]--;
                }
                y6[n1][n2][n3][n4][n5][n6]--;
                if (y6[n1][n2][n3][n4][n5][n6] == 0) {
                    X[i]--;
                }
                n1 = b[i + n - 1];
                n2 = b[i + n - 2];
                n3 = b[i + n - 3];
                n4 = b[i + n - 4];
                n5 = b[i + n - 5];
                n6 = b[i + n - 6];
                y1[n1]++;
                if (y1[n1] == 1) {
                    X[i]++;
                }
                y2[n2][n1]++;
                if (y2[n2][n1] == 1) {
                    X[i]++;
                }
                y3[n3][n2][n1]++;
                if (y3[n3][n2][n1] == 1) {
                    X[i]++;
                }
                y4[n4][n3][n2][n1]++;
                if (y4[n4][n3][n2][n1] == 1) {
                    X[i]++;
                }
                y5[n5][n4][n3][n2][n1]++;
                if (y5[n5][n4][n3][n2][n1] == 1) {
                    X[i]++;
                }
                y6[n6][n5][n4][n3][n2][n1]++;
                if (y6[n6][n5][n4][n3][n2][n1] == 1) {
                    X[i]++;
                }
                X[i - 1] = (X[i - 1] * 100) / t;
            }
        }

        if (k == 5) {
            int[][][][] y4 = new int[5][5][5][5];
            int[][][][][] y5 = new int[5][5][5][5][5];
            for (i = 0; i < n - 4; i++) {
                n1 = b[i];
                n2 = b[i + 1];
                n3 = b[i + 2];
                n4 = b[i + 3];
                n5 = b[i + 4];
                y1[n1]++;
                if (y1[n1] == 1) {
                    X[0]++;
                }
                y2[n1][n2]++;
                if (y2[n1][n2] == 1) {
                    X[0]++;
                }
                y3[n1][n2][n3]++;
                if (y3[n1][n2][n3] == 1) {
                    X[0]++;
                }
                y4[n1][n2][n3][n4]++;
                if (y4[n1][n2][n3][n4] == 1) {
                    X[0]++;
                }
                y5[n1][n2][n3][n4][n5]++;
                if (y5[n1][n2][n3][n4][n5] == 1) {
                    X[0]++;
                }
            }
            y4[n2][n3][n4][n5]++;
            if (y4[n2][n3][n4][n5] == 1) {
                X[0]++;
            }
            y3[n3][n4][n5]++;
            if (y3[n3][n4][n5] == 1) {
                X[0]++;
            }
            y3[n2][n3][n4]++;
            if (y3[n2][n3][n4] == 1) {
                X[0]++;
            }
            y2[n4][n5]++;
            if (y2[n4][n5] == 1) {
                X[0]++;
            }
            y2[n3][n4]++;
            if (y2[n3][n4] == 1) {
                X[0]++;
            }
            y2[n2][n3]++;
            if (y2[n2][n3] == 1) {
                X[0]++;
            }
            y1[n2]++;
            if (y1[n2] == 1) {
                X[0]++;
            }
            y1[n3]++;
            if (y1[n3] == 1) {
                X[0]++;
            }
            y1[n4]++;
            if (y1[n4] == 1) {
                X[0]++;
            }
            y1[n5]++;
            if (y1[n5] == 1) {
                X[0]++;
            }
            for (i = 1; i < l - n + 1; i++) {
                X[i] = X[i - 1];
                n1 = b[i - 1];
                n2 = b[i];
                n3 = b[i + 1];
                n4 = b[i + 2];
                n5 = b[i + 3];
                y1[n1]--;
                if (y1[n1] == 0) {
                    X[i]--;
                }
                y2[n1][n2]--;
                if (y2[n1][n2] == 0) {
                    X[i]--;
                }
                y3[n1][n2][n3]--;
                if (y3[n1][n2][n3] == 0) {
                    X[i]--;
                }
                y4[n1][n2][n3][n4]--;
                if (y4[n1][n2][n3][n4] == 0) {
                    X[i]--;
                }
                y5[n1][n2][n3][n4][n5]--;
                if (y5[n1][n2][n3][n4][n5] == 0) {
                    X[i]--;
                }
                n1 = b[i + n - 1];
                n2 = b[i + n - 2];
                n3 = b[i + n - 3];
                n4 = b[i + n - 4];
                n5 = b[i + n - 5];
                y1[n1]++;
                if (y1[n1] == 1) {
                    X[i]++;
                }
                y2[n2][n1]++;
                if (y2[n2][n1] == 1) {
                    X[i]++;
                }
                y3[n3][n2][n1]++;
                if (y3[n3][n2][n1] == 1) {
                    X[i]++;
                }
                y4[n4][n3][n2][n1]++;
                if (y4[n4][n3][n2][n1] == 1) {
                    X[i]++;
                }
                y5[n5][n4][n3][n2][n1]++;
                if (y5[n5][n4][n3][n2][n1] == 1) {
                    X[i]++;
                }
                X[i - 1] = (X[i - 1] * 100) / t;
            }
        }

        if (k == 4) {
            int[][][][] y4 = new int[5][5][5][5];
            for (i = 0; i < n - 3; i++) {
                n1 = b[i];
                n2 = b[i + 1];
                n3 = b[i + 2];
                n4 = b[i + 3];
                y1[n1]++;
                if (y1[n1] == 1) {
                    X[0]++;
                }
                y2[n1][n2]++;
                if (y2[n1][n2] == 1) {
                    X[0]++;
                }
                y3[n1][n2][n3]++;
                if (y3[n1][n2][n3] == 1) {
                    X[0]++;
                }
                y4[n1][n2][n3][n4]++;
                if (y4[n1][n2][n3][n4] == 1) {
                    X[0]++;
                }
            }
            y3[n2][n3][n4]++;
            if (y3[n2][n3][n4] == 1) {
                X[0]++;
            }
            y2[n3][n4]++;
            if (y2[n3][n4] == 1) {
                X[0]++;
            }
            y2[n2][n3]++;
            if (y2[n2][n3] == 1) {
                X[0]++;
            }
            y1[n2]++;
            if (y1[n2] == 1) {
                X[0]++;
            }
            y1[n3]++;
            if (y1[n3] == 1) {
                X[0]++;
            }
            y1[n4]++;
            if (y1[n4] == 1) {
                X[0]++;
            }
            for (i = 1; i < l - n + 1; i++) {
                X[i] = X[i - 1];
                n1 = b[i - 1];
                n2 = b[i];
                n3 = b[i + 1];
                n4 = b[i + 2];
                y1[n1]--;
                if (y1[n1] == 0) {
                    X[i]--;
                }
                y2[n1][n2]--;
                if (y2[n1][n2] == 0) {
                    X[i]--;
                }
                y3[n1][n2][n3]--;
                if (y3[n1][n2][n3] == 0) {
                    X[i]--;
                }
                y4[n1][n2][n3][n4]--;
                if (y4[n1][n2][n3][n4] == 0) {
                    X[i]--;
                }
                n1 = b[i + n - 1];
                n2 = b[i + n - 2];
                n3 = b[i + n - 3];
                n4 = b[i + n - 4];
                y1[n1]++;
                if (y1[n1] == 1) {
                    X[i]++;
                }
                y2[n2][n1]++;
                if (y2[n2][n1] == 1) {
                    X[i]++;
                }
                y3[n3][n2][n1]++;
                if (y3[n3][n2][n1] == 1) {
                    X[i]++;
                }
                y4[n4][n3][n2][n1]++;
                if (y4[n4][n3][n2][n1] == 1) {
                    X[i]++;
                }
                X[i - 1] = (X[i - 1] * 100) / t;
            }
        }

        if (k == 3) {
            for (i = 0; i < n - 2; i++) {
                n1 = b[i];
                n2 = b[i + 1];
                n3 = b[i + 2];
                y1[n1]++;
                if (y1[n1] == 1) {
                    X[0]++;
                }
                y2[n1][n2]++;
                if (y2[n1][n2] == 1) {
                    X[0]++;
                }
                y3[n1][n2][n3]++;
                if (y3[n1][n2][n3] == 1) {
                    X[0]++;
                }
            }
            y2[n2][n3]++;
            if (y2[n2][n3] == 1) {
                X[0]++;
            }
            y1[n2]++;
            if (y1[n2] == 1) {
                X[0]++;
            }
            y1[n3]++;
            if (y1[n3] == 1) {
                X[0]++;
            }
            for (i = 1; i < l - n + 1; i++) {
                X[i] = X[i - 1];
                n1 = b[i - 1];
                n2 = b[i];
                n3 = b[i + 1];
                y1[n1]--;
                if (y1[n1] == 0) {
                    X[i]--;
                }
                y2[n1][n2]--;
                if (y2[n1][n2] == 0) {
                    X[i]--;
                }
                y3[n1][n2][n3]--;
                if (y3[n1][n2][n3] == 0) {
                    X[i]--;
                }
                n1 = b[i + n - 1];
                n2 = b[i + n - 2];
                n3 = b[i + n - 3];
                y1[n1]++;
                if (y1[n1] == 1) {
                    X[i]++;
                }
                y2[n2][n1]++;
                if (y2[n2][n1] == 1) {
                    X[i]++;
                }
                y3[n3][n2][n1]++;
                if (y3[n3][n2][n1] == 1) {
                    X[i]++;
                }
                X[i - 1] = (X[i - 1] * 100) / t;
            }
        }

        if (k == 2) {
            for (i = 0; i < n - 1; i++) {
                n1 = b[i];
                n2 = b[i + 1];
                y1[n1]++;
                if (y1[n1] == 1) {
                    X[0]++;
                }
                y2[n1][n2]++;
                if (y2[n1][n2] == 1) {
                    X[0]++;
                }
            }
            y1[n2]++;
            if (y1[n2] == 1) {
                X[0]++;
            }
            for (i = 1; i < l - n + 1; i++) {
                X[i] = X[i - 1];
                n1 = b[i - 1];
                n2 = b[i];
                y1[n1]--;
                if (y1[n1] == 0) {
                    X[i]--;
                }
                y2[n1][n2]--;
                if (y2[n1][n2] == 0) {
                    X[i]--;
                }
                n1 = b[i + n - 1];
                n2 = b[i + n - 2];
                y1[n1]++;
                if (y1[n1] == 1) {
                    X[i]++;
                }
                y2[n2][n1]++;
                if (y2[n2][n1] == 1) {
                    X[i]++;
                }
                X[i - 1] = (X[i - 1] * 100) / t;
            }
        }
        X[l - n] = (X[l - n] * 100) / t;
        return X;
    }

    public static double[] PlotTm(String source, int k, double kcl, double pri) {
        int l = source.length();
        if (k < minoligolen) {
            k = minoligolen;
        }
        if (l < k || l < minoligolen) {
            return null;
        }
        if (l < k) {
            k = l;
        }
        double cg = 0d;
        double dS = -5.7d;
        double dH = 200d;
        double salt = 77.1 + 11.7 * Math.log10(0.05);

        double[] r = new double[1 + l - k];
        if (k < 51) {
            int n1 = 0;
            int n2 = 0;
            for (int i = 0; i < k - 1; i++) {
                n1 = source.charAt(i);
                n2 = source.charAt(i + 1);
                dH = dH + oligoparam.dHUni[tables.dn[n1]][tables.dn[n2]];
                dS = dS + oligoparam.dSUni[tables.dn[n1]][tables.dn[n2]];
            }
            r[0] = (dH / (dS - 45.0905951329681d)) - 273.15;
            for (int i = 1; i < l - k + 1; i++) {
                n1 = source.charAt(i - 1);
                n2 = source.charAt(i);
                dH = dH - oligoparam.dHUni[tables.dn[n1]][tables.dn[n2]];
                dS = dS - oligoparam.dSUni[tables.dn[n1]][tables.dn[n2]];
                n1 = source.charAt(i + k - 2);
                n2 = source.charAt(i + k - 1);
                dH = dH + oligoparam.dHUni[tables.dn[n1]][tables.dn[n2]];
                dS = dS + oligoparam.dSUni[tables.dn[n1]][tables.dn[n2]];
                r[i] = (dH / (dS - 45.0905951329681d)) - 273.15;
            }
        } else {
            //77.1 + (11.7 * (Log(solt) / Log(10))) - 528 / l
            for (int i = 0; i < k; i++) {
                cg += tables.cgv[source.charAt(i)];
            }
            r[0] = ((0.41 * cg - 528) / k) + salt;
            for (int i = 1; i < l - k + 1; i++) {
                cg = cg - tables.cgv[source.charAt(i - 1)] + tables.cgv[source.charAt(i + k - 1)];
                r[i] = ((0.41 * cg - 528) / k) + salt;
            }
        }
        return r;
    }
}
