
import java.util.ArrayList;
import java.util.List;
import java.io.IOException;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;

public class virtualpcr {

    public static void main(String[] args) {
        if (args.length > 0) {
            String currentDirectory = System.getProperty("user.dir");
            System.out.println("Current Directory: " + currentDirectory);
            System.out.println("Command-line arguments:");

            String infile = args[0];
            String tagfile = "";
            String primersfile = "";
            String s = String.join(" ", args).toLowerCase() + " ";

            int minlen = 30;
            int maxlen = 3000;
            int level = 0; //=1 slow, =3 fast
            int Err3end = 1;

            boolean isprobe = false;
            boolean ispattern = false;
            boolean iscircle = false;
            boolean seqextract = false;
            boolean FRpairs = false;              //SetLookR_Fprimes
            boolean pcr_predict = true;           //SetShowPCRProducts
            boolean CalculatePCRproduct = false;  //SetShowPCRproductCalculation
            boolean alignment = true;             //SetShowPrimerAlignment
            boolean ShowOnlyAmplicons = false;    //SetShowOnlyAmplicons
            boolean PCRmatch_alignment = true;    //SetShowPrimerAlignmentPCRproduct

            try (BufferedReader br = new BufferedReader(new FileReader(infile))) {
                int h = 0;
                String line;
                while ((line = br.readLine()) != null) {
                    System.out.println(line);
                    line=line.toLowerCase();
                    if (line.contains("targets_path=")) {
                        tagfile = line.substring(13);
                    }
                    if (line.contains("primers_path=")) {
                        primersfile = line.substring(13);
                    }
                    if (line.contains("type=probe")) {
                        isprobe = true;
                    }
                    if (line.contains("molecular=circle")) {
                        iscircle = true;
                    }
                    if (line.contains("linkedsearch=true")) {
                        ispattern = true;
                    }
                    if (line.contains("showprimeralignmentpcrproduct=true")) {
                        PCRmatch_alignment = true;
                    }
                    if (line.contains("frpairs=true")) {
                        FRpairs = true;
                    }
                    if (line.contains("showprimeralignment=false")) {
                        alignment = false;
                    }
                    if (line.contains("showpcrproducts=false")) {
                        pcr_predict = false;
                    }
                    if (line.contains("showpcrproductcalculation=true")) {
                        CalculatePCRproduct = true;
                    }
                    if (line.contains("showonlyamplicons=true")) {
                        ShowOnlyAmplicons = true;
                    }

                    if (line.contains("number3errors=")) {
                        h = StrToInt(line.substring(15));
                        if (h < 0) {
                            h = 0;
                        }
                        if (h > 10) {
                            h = 10;
                        }
                        Err3end = h;
                    }
                    if (line.contains("minlen=")) {
                        h = StrToInt(line.substring(6));
                        if (h < 20) {
                            h = 20;
                        }
                        if (h > 50000) {
                            h = 50000;
                        }
                        minlen = h;
                    }
                    if (line.contains("maxlen=")) {
                        h = StrToInt(line.substring(6));
                        if (h < minlen) {
                            h = minlen;
                        }
                        if (h > 50000) {
                            h = 50000;
                        }
                        maxlen = h;
                    }

                }
            } catch (IOException e) {
            }

            String[] PrimersList = new String[1];
            String[] PrimersName = new String[1];
            String[] PrimersOri = new String[1];

            try (BufferedReader br = new BufferedReader(new FileReader(primersfile))) {
                List<String> lines = new ArrayList<>();
                String line;
                int n = 0;
                while ((line = br.readLine()) != null) {
                    System.out.println(line);  
                    lines.add(line);
                }

                PrimersList = new String[lines.size()];
                PrimersName = new String[lines.size()];
                PrimersOri = new String[lines.size()];

                for (String x : lines) {
                    String[] a = x.split("[ \t]+");
                    PrimersName[n] = a[0];
                    PrimersOri[n] = a[1].toLowerCase();
                    PrimersList[n] = dna.DNA(a[1].toLowerCase());
                    n++;
                }
            } catch (IOException e) {
            }

            File folder = new File(tagfile);
            if (folder.exists() && (folder.isDirectory() || folder.isFile())) {
                if (folder.isDirectory()) {
                    File[] files = folder.listFiles();
                    int k = -1;
                    String[] filelist = new String[files.length];
                    for (File file : files) {
                        if (file.isFile()) {
                            filelist[++k] = file.getAbsolutePath();
                        }
                    }
                    for (String nfile : filelist) {
                        try {
                            Run(nfile, PrimersList, PrimersName, PrimersOri, isprobe, ispattern, iscircle, seqextract, level, Err3end, minlen, maxlen, FRpairs, pcr_predict, CalculatePCRproduct, alignment, ShowOnlyAmplicons, PCRmatch_alignment);
                        } catch (Exception e) {
                            System.err.println("Failed to open file: " + nfile);
                        }
                    }

                } else {
                    Run(tagfile, PrimersList, PrimersName, PrimersOri, isprobe, ispattern, iscircle, seqextract, level, Err3end, minlen, maxlen, FRpairs, pcr_predict, CalculatePCRproduct, alignment, ShowOnlyAmplicons, PCRmatch_alignment);
                }
            }

        } else {
            System.out.println("virtualPCR (2024) by Ruslan Kalendar (ruslan.kalendar@helsinki.fi)\nhttps://primerdigital.com/tools/\n");
            System.out.println("Basic usage:");
            System.out.println("java -jar \\virtualPCR\\dist\\virtualPCR.jar <config.file>");
            System.out.println("Common options:");

        }
    }

    private static void Run(String tagfile, String[] PrimersList, String[] PrimersName, String[] PrimersOri, boolean isprobe, boolean ispattern, boolean iscircle, boolean seqextract, int level, int Err3end, int minlen, int maxlen, boolean FRpairs, boolean pcr_predict, boolean CalculatePCRproduct, boolean alignment, boolean ShowOnlyAmplicons, boolean PCRmatch_alignment) {
        String outfile = tagfile + ".out";
        try {

            StringBuilder sr = new StringBuilder(100000);
            InSilicoPCR2 s2 = new InSilicoPCR2();
            long startTime = System.nanoTime();
            byte[] binaryArray = Files.readAllBytes(Paths.get(tagfile));
            ReadingSequencesFiles rf = new ReadingSequencesFiles(binaryArray);
            System.out.println("\nTarget file name: " + tagfile);
            System.out.println("Target sequence length = " + rf.getLength() + " nt");
            System.out.println("Running...");
            s2.SetSequences(rf.getSequences(), rf.getNames());
            s2.SetShowPrimerAlignment(true);
            s2.SetShowPrimerAlignmentPCRproduct(true);
            s2.SetShowOnlyAmplicons(false);
            s2.SetLookR_Fprimes(FRpairs);
            s2.SetShowPCRProducts(pcr_predict);
            s2.SetShowPCRproductCalculation(CalculatePCRproduct);
            s2.SetShowPrimerAlignment(alignment);
            s2.SetShowOnlyAmplicons(ShowOnlyAmplicons);
            s2.SetShowPrimerAlignmentPCRproduct(PCRmatch_alignment);
            s2.SetProductMaxLength(maxlen);
            s2.SetProductMinLength(minlen);
            s2.SetPrimers(PrimersList, PrimersName, PrimersOri, isprobe, ispattern, iscircle, seqextract, level, Err3end);
            s2.Run();
            sr.append(s2.getResult());
            System.out.println(sr);

            try (FileWriter fileWriter = new FileWriter(outfile)) {
                System.out.println("Saving report file: " + outfile);
                fileWriter.write(sr.toString());
            }

            long duration = (System.nanoTime() - startTime) / 1000000000;
            System.out.println("Time taken: " + duration + " seconds\n\n");
        } catch (IOException e) {
            System.out.println("Incorrect file name.\n");
        }
    }

    public static int StrToInt(String str) {
        StringBuilder r = new StringBuilder();
        int z = 0;
        r.append(0);
        for (int i = 0; i < str.length(); i++) {
            char chr = str.charAt(i);
            if (chr > 47 && chr < 58) {
                r.append(chr);
                z++;
                if (z > 10) {
                    break;
                }
            }
            if (chr == '.' || chr == ',') {
                break;
            }
        }
        return (Integer.parseInt(r.toString()));
    }
}
